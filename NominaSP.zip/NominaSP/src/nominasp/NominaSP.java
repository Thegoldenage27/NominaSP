package nominasp;
import java.sql.*;

public class NominaSP {
Connection con=null;
private static String url="jdbc:postgresql://localhost:5432/mydb";
private static String usuario="postgres";
private static String clave="311239902";
private static Connection connection;

public static void main(String[] args) {
try{
ResultSet rs;
Class.forName("org.postgresql.Driver");
Connection con=DriverManager.getConnection(url, usuario, clave);

 // instrucciones para usar call

 CallableStatement cst=con.prepareCall ("call nomina ()");
cst.execute();

// instruccion para select
PreparedStatement pstmt=con.prepareStatement ("select count(nss) as error from empleado where total is null");
rs=pstmt.executeQuery ();
while (rs.next())
{
    if (rs.getString(1).equals("0")){
        System.out.println("Transaccion realizada correctamente");
        
    }else{
        System.out.println("Transaccion no realizada");
    }
    }

}catch (Exception e){
        System.out.println("Error en conexion...!"+e.getMessage());
        }
}}